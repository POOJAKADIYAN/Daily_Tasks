package net.codejava;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Controller
public class UserController   //controller class for handling the GET and POST requests
{
	@GetMapping("/new")   //getmapping maps the /new URL pattern to the showform() method.
	public String showForm(Model model)
	{
		User user = new User();   //creates object of the model class
		model.addAttribute("user", user);  //model receives a user attribute with the add attribute method
		return "register_form";
	}	
    @PostMapping("/register")  //postmapping maps the /register URL pattern to the saveUser() method.
	public String saveUser(@ModelAttribute("user") User user) 
    {	 
    	String INSERT_USERS_SQL = "INSERT INTO users" + "(username, email, password) VALUES" + "(?, ?, ?);";
      try
      {  
    	  Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/test?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC", "root", "");
          PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL);  //we need statements or prepared statements in order to execute the query in database using java
          String regex = "^[\\w!#$%&'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";  //regex pattern for validating email id field
          Pattern pattern = Pattern.compile(regex);
          Matcher matcher = pattern.matcher(user.getEmail());  //returns true if email id is valid
          if(!matcher.matches()) {
        	  return "error_page";  //email id is invalid, so we go to error page for now instead we can just add alert pop-up using JS
          }
          PreparedStatement ps;
          ResultSet rs;
          //boolean checkUser = false;
          String query = "SELECT * FROM `users` WHERE `email` = ?";  //query for checking if email id already exists in the DB
          ps = connection.prepareStatement(query);
          ps.setString(1,user.getEmail());  //putting the now entered email id in the query 
          rs = ps.executeQuery(); // executes the query and fetches any row that has the same email id as entered by the user
          if(rs.next())
          {
        	  return "error_page";
          }
          preparedStatement.setString(1, user.getUsername());  //replaces 1st ? in query with username
          preparedStatement.setString(2, user.getEmail());
          preparedStatement.setString(3, user.getPassword());
          //System.out.println("Done Done");
          //System.out.println(user.getUsername()+ " named having " + user.getEmail() + " and passcode as " + user.getPassword());
          System.out.println(preparedStatement);
          int i = preparedStatement.executeUpdate();  //returns 1 if query goes to the database o/w 0
          //System.out.println(i);  
      } 
      catch (SQLException e) //catches excption
      {
          e.printStackTrace(System.err);  //prints error stack tree in case of exception
      }
    System.out.println(user);
		return "register_success";  //goes to register_success page
    }
}



