package net.codejava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoFormApplication { //spring boot application class

	public static void main(String[] args) {
		SpringApplication.run(DemoFormApplication.class, args);
	}

}



